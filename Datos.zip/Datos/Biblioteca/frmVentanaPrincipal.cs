﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Biblioteca
{
    public partial class frmVentanaPrincipal : Form
    {
        public frmVentanaPrincipal()
        {
            InitializeComponent();
        }

        private void btnProductos_Click(object sender, EventArgs e)
        {
            fmrInventario frm = new fmrInventario();
            frm.ShowDialog();
            this.Close();
        }

        private void btnAreas_Click(object sender, EventArgs e)
        {
            frmAreas frm = new frmAreas();
            frm.ShowDialog();
            this.Close();
        }
    }
}

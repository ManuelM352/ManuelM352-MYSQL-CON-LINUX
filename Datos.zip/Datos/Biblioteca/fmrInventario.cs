﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Datos;

namespace Biblioteca
{
    public partial class fmrInventario : Form
    {
        public bool Borrado { get; set; }
        public fmrInventario()
        {
            InitializeComponent();
            cargarTabla();                        
        }

        public void cargarTabla()
        {
            dgvDatos.DataSource = new DAOInventario().ObtenerTodos();
            dgvDatos.Columns["id"].HeaderText = "ID";
            dgvDatos.Columns["nombre"].HeaderText = "Nombre";
            dgvDatos.Columns["descripcion"].HeaderText = "Descripcion";
            dgvDatos.Columns["serie"].HeaderText = "Serie";
            dgvDatos.Columns["color"].HeaderText = "Color";
            dgvDatos.Columns["area"].HeaderText = "Area";
            dgvDatos.Columns["observaciones"].HeaderText = "Observaciones";            
        }
        private void btnAgregar_Click(object sender, EventArgs e)
        {
            frmAgregar frm = new frmAgregar();
            frm.ShowDialog();
            if (frm.Guardado)
            {
                //Actualizar la lista
                cargarTabla();
            }            
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            String idProducto = dgvDatos.SelectedRows[0].Cells["ID"].Value.ToString();
            frmAgregar frm = new frmAgregar(idProducto);
            frm.ShowDialog();
            if (frm.Guardado)
            {
                cargarTabla();
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (dgvDatos.SelectedRows.Count == 0)
            {
                MessageBox.Show("Selecciona un producto a eliminar", "Error", MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
            else
            {
                if (MessageBox.Show("¿Está seguro de eliminar el producto " + "?", "Confirmación",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    try
                    {
                        String idProducto = dgvDatos.SelectedRows[0].Cells["ID"].Value.ToString();                        
                        if (new DAOInventario().eliminar(idProducto))
                        {
                            Borrado = true;
                            MessageBox.Show("Producto eliminado correctamente", "Eliminado",
                                MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            cargarTabla();
        }
    }
}

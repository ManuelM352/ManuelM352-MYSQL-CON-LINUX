﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Modelos;
using Datos;
using MySql.Data.MySqlClient;


namespace Datos
{
    public class DAOInventario
    {
        public List<Inventario> ObtenerTodos()
        {
            try
            {
                if (Conexion.conectar())
                {
                    MySqlCommand comando = new MySqlCommand(
                        @" SELECT p.*, c.nombre FROM productos p JOIN areas c ON c.id=p.area;");                    
                    comando.Connection = Conexion.conexion;                    
                    MySqlDataAdapter adapter = new MySqlDataAdapter(comando);
                    DataTable resultado = new DataTable();
                    adapter.Fill(resultado);
                    List<Inventario> lista = new List<Inventario>();
                    Inventario objProducto = null;                    

                    foreach (DataRow fila in resultado.Rows)
                    {
                        objProducto = new Inventario();                    
                        objProducto.Id = Convert.ToInt32(fila["id"]);
                        objProducto.Nombre = fila["nombre"].ToString();                        
                        objProducto.Descripcion = fila["descripcion"].ToString();
                        objProducto.Serie = fila["serie"].ToString();
                        objProducto.Color = fila["color"].ToString();                        
                        objProducto.Fecha_ad = Convert.ToDateTime(fila["fecha"]);                        
                        objProducto.TipoAdquisicion = fila["adquisicion"].ToString();
                        objProducto.Area = Convert.ToInt32(fila["area"]);
                        objProducto.Observaciones = fila["observaciones"].ToString();
                        lista.Add(objProducto);
                    }
                    return lista;
                }
                else
                {
                    throw new Exception("No se ha podido conectar con el servidor");
                }
            }
            catch (MySqlException ex)
            {
                throw new Exception("No se pudo obtener la información de los productos");
            }
            finally
            {
                Conexion.desconectar();
            }
        }
        public Inventario ObtenerUno(string id)
        {
            try
            {
                if (Conexion.conectar())
                {         
                    MySqlCommand comando = new MySqlCommand(
                        @" SELECT * FROM productos WHERE id=@id");
                    comando.Parameters.AddWithValue("@id", id);                 
                    comando.Connection = Conexion.conexion;                    
                    MySqlDataAdapter adapter = new MySqlDataAdapter(comando);
                    DataTable resultado = new DataTable();
                    adapter.Fill(resultado);
                    Inventario objProducto = null;                    
                    if (resultado.Rows.Count > 0)
                    {
                        DataRow fila = resultado.Rows[0];
                        objProducto = new Inventario();                        
                        objProducto.Id = Convert.ToInt32(fila["id"]);
                        objProducto.Nombre = fila["nombre"].ToString();
                        objProducto.Descripcion = fila["descripcion"].ToString();
                        objProducto.Serie = fila["serie"].ToString();
                        objProducto.Color = fila["color"].ToString();                        
                        objProducto.Fecha_ad = Convert.ToDateTime(fila["fecha"]);                        
                        objProducto.TipoAdquisicion = fila["adquisicion"].ToString();
                        objProducto.Area = Convert.ToInt32(fila["area"]);
                        objProducto.Observaciones = fila["observaciones"].ToString();
                    }
                    return objProducto;
                }
                else
                {
                    throw new Exception("No se ha podido conectar con el servidor");
                }
            }
            catch (MySqlException ex)
            {
                throw new Exception("No se pudo obtener la información del producto");
            }
            finally
            {
                Conexion.desconectar();
            }
        }
        public bool eliminar(string id)
        {
            try
            {
                if (Conexion.conectar())
                {        
                    MySqlCommand comando = new MySqlCommand(
                        @"DELETE FROM productos WHERE id=@id;");
                    comando.Parameters.AddWithValue("@id", Convert.ToInt32(id));                    
                    comando.Connection = Conexion.conexion;
                    int filasBorradas = comando.ExecuteNonQuery();
                    return (filasBorradas > 0);
                }
                else
                {
                    throw new Exception("No se ha podido conectar con el servidor");
                }
            }
            catch (MySqlException ex)
            {
                if (ex.Number != 1451)
                {
                    throw new Exception("No se puede eliminar el producto)");
                }
                else
                {
                    MySqlCommand comando = new MySqlCommand(
                        @"UPDATE productos
                            SET id=@id,                              
                            WHERE id=@id");
                    comando.Parameters.AddWithValue("@id", id);                                 
                    comando.Connection = Conexion.conexion;
                    int filasEditadas = comando.ExecuteNonQuery();
                    return (filasEditadas > 0);
                }
            }
            finally
            {
                Conexion.desconectar();
            }
        }
        public bool editar(Inventario productos)
        {
            try
            {
                if (Conexion.conectar())
                {         
                    MySqlCommand comando = new MySqlCommand(
                        @"UPDATE productos
                            SET id=@id, 
                            nombre=@nombre,descripcion=@descripcion,serie=@serie,
                            color=@color,fecha=@fecha,
                            adquisicion=@adquisicion, area = @area, observaciones=@observaciones
                            WHERE id=@id");

                    comando.Parameters.AddWithValue("@id", productos.Id);
                    comando.Parameters.AddWithValue("@nombre", productos.Nombre);
                    comando.Parameters.AddWithValue("@descripcion", productos.Descripcion);
                    comando.Parameters.AddWithValue("@serie", productos.Serie);
                    comando.Parameters.AddWithValue("@color", productos.Color);
                    comando.Parameters.AddWithValue("@fecha", productos.Fecha_ad);
                    comando.Parameters.AddWithValue("@adquisicion", productos.TipoAdquisicion);
                    comando.Parameters.AddWithValue("@area", productos.Area);
                    comando.Parameters.AddWithValue("@observaciones", productos.Observaciones);                 
                    comando.Connection = Conexion.conexion;
                    int filasEditadas = comando.ExecuteNonQuery();
                    return (filasEditadas > 0);
                }
                else
                {
                    throw new Exception("No se ha podido conectar con el servidor");
                }
            }
            catch (MySqlException ex)
            {
                if (ex.Number == 1452)
                {
                    throw new Exception("No se pudo realizar la edición");
                }
                else if (ex.Number == 1062)
                {
                    throw new Exception("No se pudo realizar la edición, el nombre de producto ya se encuentra en uso");
                }
                else
                {
                    throw new Exception("No se pudo realizar la edición");
                }
            }
            finally
            {
                Conexion.desconectar();
            }
        }        
        public int agregar(Inventario productos)
        {
            try
            {
                if (Conexion.conectar())
                {
                    MySqlCommand comando = new MySqlCommand(
                        @"INSERT INTO productos
                          VALUES(@id, @nombre, @descripcion, @serie, @color,
                                @fecha, @adquisicion, @area, @observaciones);");

                    comando.Parameters.AddWithValue("@id", productos.Id);
                    comando.Parameters.AddWithValue("@nombre", productos.Nombre);
                    comando.Parameters.AddWithValue("@descripcion", productos.Descripcion);
                    comando.Parameters.AddWithValue("@serie", productos.Serie);
                    comando.Parameters.AddWithValue("@color", productos.Color);
                    comando.Parameters.AddWithValue("@fecha", productos.Fecha_ad);
                    comando.Parameters.AddWithValue("@adquisicion", productos.TipoAdquisicion);
                    comando.Parameters.AddWithValue("@area", productos.Area);
                    comando.Parameters.AddWithValue("@observaciones", productos.Observaciones);                             
                    comando.Connection = Conexion.conexion;
                    int filasAgregadas = Convert.ToInt32(comando.ExecuteScalar());
                    return filasAgregadas;
                }
                else
                {
                    throw new Exception("No se ha podido conectar con el servidor");
                }
            }
            catch (MySqlException ex)
            {
                if (ex.Number == 1452)
                {
                    throw new Exception("No se pudo realizar el registro");
                }
                else if (ex.Number == 1062)
                {
                    throw new Exception("No se pudo realizar el registro");
                }
                else
                {
                    throw new Exception("No se pudo realizar el registro");
                }
            }
            finally
            {
                Conexion.desconectar();
            }
        }
    }
}

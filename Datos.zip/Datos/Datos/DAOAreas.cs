﻿using Modelos;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Modelos;
using Datos;
namespace Datos
{
    public class DAOAreas
    {
        public List<Areas> ObtenerTodos()
        {
            try
            {
                if (Conexion.conectar())
                {
                    MySqlCommand comando = new MySqlCommand(@"SELECT * from areas");            
                    comando.Connection = Conexion.conexion;                    
                    MySqlDataAdapter adapter = new MySqlDataAdapter(comando);
                    DataTable resultado = new DataTable();
                    adapter.Fill(resultado);
                    List<Areas> lista = new List<Areas>();
                    Areas objCategoria = null;                    

                    foreach (DataRow fila in resultado.Rows)
                    {
                        objCategoria = new Areas();
                        objCategoria.Id = Convert.ToInt32(fila["Id"]);
                        objCategoria.Nombre = fila["Nombre"].ToString();
                        objCategoria.Ubicacion = fila["ubicacion"].ToString();

                        lista.Add(objCategoria);
                    }
                    return lista;
                }
                else
                {
                    throw new Exception("No se ha podido conectar con el servidor");
                }
            }
            catch (MySqlException ex)
            {
                throw new Exception("No se pudo obtener la información de las Áreas");
            }
            finally
            {
                Conexion.desconectar();
            }
        }

        public Areas ObtenerUno(int id)
        {
            try
            {
                if (Conexion.conectar())
                {
                    MySqlCommand comando = new MySqlCommand(
                        @"SELECT * FROM areas
                        WHERE Id=@Id");

                    comando.Parameters.AddWithValue("@Id", id);
                    comando.Connection = Conexion.conexion;                    
                    MySqlDataAdapter adapter = new MySqlDataAdapter(comando);
                    DataTable resultado = new DataTable();
                    adapter.Fill(resultado);
                    Areas objAreas = null;                    

                    if (resultado.Rows.Count > 0)
                    {
                        DataRow fila = resultado.Rows[0];
                        objAreas = new Areas();
                        objAreas.Id = Convert.ToInt32(fila["Id"]);
                        objAreas.Nombre = fila["Nombre"].ToString();
                        objAreas.Ubicacion = fila["ubicacion"].ToString();
                    }
                    return objAreas;
                }
                else
                {
                    throw new Exception("No se ha podido conectar con el servidor");
                }
            }
            catch (MySqlException ex)
            {
                throw new Exception("No se pudo obtener la información de las Áreas");
            }
            finally
            {
                Conexion.desconectar();
            }
        }
        public int agregar(Areas categoria)
        {
            try
            {
                if (Conexion.conectar())
                {
                    MySqlCommand comando = new MySqlCommand(
                        @"INSERT INTO areas(id,Nombre, ubicacion)
                        VALUES(@Id,@Nombre, @ubicacion);");

                    comando.Parameters.AddWithValue("@id", categoria.Id);
                    comando.Parameters.AddWithValue("@Nombre", categoria.Nombre);
                    comando.Parameters.AddWithValue("@ubicacion", categoria.Ubicacion);                    
                    comando.Connection = Conexion.conexion;
                    int filasAgregadas = comando.ExecuteNonQuery();
                    return filasAgregadas;
                }
                else
                {
                    throw new Exception("No se ha podido conectar con el servidor");
                }
            }
            catch (MySqlException ex)
            {
                if (ex.Number == 1062)
                {
                    throw new Exception("No se pudo realizar el registro, el nombre de área ya se encuentra en uso");
                }
                else if (ex.Number == 1452)
                {
                    throw new Exception("No se pudo realizar el registro, fallo en llenado de llaves foráneas");
                }
                else
                {
                    throw new Exception("No se pudo realizar el registro");
                }
            }
            finally
            {
                Conexion.desconectar();
            }
        }

        public bool editar(Areas categoria)
        {
            try
            {
                if (Conexion.conectar())
                {
                    MySqlCommand comando = new MySqlCommand(
                        @"UPDATE areas
                            SET id=@Id, Nombre=@Nombre, 
                            Ubicacion=@ubicacion WHERE Id=@Id");

                    comando.Parameters.AddWithValue("@Id", categoria.Id);
                    comando.Parameters.AddWithValue("@Nombre", categoria.Nombre);
                    comando.Parameters.AddWithValue("@ubicacion", categoria.Ubicacion);

                    comando.Connection = Conexion.conexion;
                    int filasBorradas = comando.ExecuteNonQuery();
                    return (filasBorradas > 0);
                }
                else
                {
                    throw new Exception("No se ha podido conectar con el servidor");
                }
            }
            catch (MySqlException ex)
            {
                if (ex.Number == 1062)
                {
                    throw new Exception("No se pudo realizar la modificación, el nombre de área ya se encuentra en uso");
                }
                else if (ex.Number == 1452)
                {
                    throw new Exception("No se pudo realizar la modificación, fallo en llenado de llaves foráneas");
                }
                else
                {
                    MySqlCommand comando = new MySqlCommand(
                        @"UPDATE areas
                            SET id=@Id, Nombre=@Nombre, 
                            Ubicacion=@ubicacion WHERE Id=@Id");

                    comando.Parameters.AddWithValue("@Id", categoria.Id);
                    comando.Parameters.AddWithValue("@Nombre", categoria.Nombre);
                    comando.Parameters.AddWithValue("@ubicacion", categoria.Ubicacion);

                    comando.Connection = Conexion.conexion;
                    int filasBorradas = comando.ExecuteNonQuery();
                    return (filasBorradas > 0);
                }
            }
            finally
            {
                Conexion.desconectar();
            }
        }
    
        public bool eliminar(int id)
        {
            try
            {
                if (Conexion.conectar())
                {
                    MySqlCommand comando = new MySqlCommand(
                        @"DELETE FROM areas 
                            WHERE Id=@id");

                    comando.Parameters.AddWithValue("@id", id);
                    comando.Connection = Conexion.conexion;
                    int filasBorradas = comando.ExecuteNonQuery();
                    return (filasBorradas > 0);
                }
                else
                {
                    throw new Exception("No se ha podido conectar con el servidor");
                }
            }
            catch (MySqlException ex)
            {                
                throw new Exception("Error al intentar eliminar la categoría");              
            }
            finally
            {
                Conexion.desconectar();
            }
        }        
    }
}
